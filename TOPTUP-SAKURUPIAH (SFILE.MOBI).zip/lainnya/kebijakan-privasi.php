<?php
session_start();
require '../config.php';
require '../lib/header.php';

?>

<div class="section-container py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">Kebijakan Privasi</h2>
      <p class="text-muted">Privasi Anda adalah prioritas kami</p>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <h5 class="fw-semibold">1. Pengumpulan Informasi</h5>
        <p>
          Kami mengumpulkan informasi pribadi seperti nama, nomor telepon, alamat email, ID game, dan informasi lain yang dibutuhkan saat pengguna melakukan transaksi atau menghubungi layanan kami.
        </p>

        <h5 class="fw-semibold">2. Penggunaan Informasi</h5>
        <p>
          Informasi yang dikumpulkan digunakan untuk keperluan pemrosesan transaksi, layanan pelanggan, pengiriman notifikasi, serta peningkatan kualitas layanan kami.
        </p>

        <h5 class="fw-semibold">3. Perlindungan Data</h5>
        <p>
          Kami berkomitmen untuk melindungi informasi pribadi pengguna. Data disimpan dengan aman dan tidak akan diperjualbelikan atau dibagikan ke pihak ketiga tanpa persetujuan, kecuali diwajibkan oleh hukum.
        </p>

        <h5 class="fw-semibold">4. Cookie & Tracking</h5>
        <p>
          Situs kami dapat menggunakan cookie dan teknologi tracking lainnya untuk meningkatkan pengalaman pengguna. Pengguna dapat mengatur preferensi cookie melalui browser masing-masing.
        </p>

        <h5 class="fw-semibold">5. Hak Pengguna</h5>
        <p>
          Pengguna berhak mengakses, memperbarui, atau menghapus informasi pribadi mereka dengan menghubungi tim kami. Kami akan menanggapi permintaan tersebut sesuai dengan kebijakan dan hukum yang berlaku.
        </p>

        <h5 class="fw-semibold">6. Perubahan Kebijakan</h5>
        <p>
          Kami dapat memperbarui kebijakan privasi ini dari waktu ke waktu. Perubahan akan ditampilkan di halaman ini, dan pengguna dianggap telah menyetujui kebijakan terbaru setelah perubahan dipublikasikan.
        </p>
      </div>
    </div>
  </div>
</div>


<?php require '../lib/footer.php'; ?>