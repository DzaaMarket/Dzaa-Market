<?php
session_start();
require '../config.php';
require '../lib/header.php';

?>

<div class="section-container py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">Syarat & Ketentuan</h2>
      <p class="text-muted">Harap membaca dengan seksama sebelum menggunakan layanan kami</p>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <h5 class="fw-semibold">1. Penggunaan Layanan</h5>
        <p>
          Dengan menggunakan layanan kami, pengguna dianggap telah menyetujui semua syarat dan ketentuan yang berlaku. Layanan hanya boleh digunakan untuk keperluan yang sah dan tidak melanggar hukum.
        </p>

        <h5 class="fw-semibold">2. Data Pengguna</h5>
        <p>
          Pengguna bertanggung jawab penuh atas data yang diberikan saat melakukan transaksi, termasuk nomor tujuan, ID game, dan informasi lainnya. Kesalahan input bukan tanggung jawab penyedia layanan.
        </p>

        <h5 class="fw-semibold">3. Transaksi & Pembayaran</h5>
        <p>
          Semua transaksi yang sudah dibayar tidak dapat dibatalkan. Kami tidak bertanggung jawab atas kerugian yang disebabkan oleh kesalahan transfer atau kegagalan sistem pihak ketiga (seperti bank atau payment gateway).
        </p>

        <h5 class="fw-semibold">4. Kebijakan Refund</h5>
        <p>
          Pengembalian dana (refund) hanya dilakukan jika transaksi gagal dan saldo tidak diterima dalam jangka waktu yang ditentukan. Permintaan refund dapat diajukan melalui kontak resmi kami.
        </p>

        <h5 class="fw-semibold">5. Perubahan Layanan</h5>
        <p>
          Kami berhak melakukan perubahan terhadap layanan, harga, dan syarat ketentuan kapan saja tanpa pemberitahuan sebelumnya. Pengguna disarankan untuk selalu memeriksa halaman ini secara berkala.
        </p>

        <h5 class="fw-semibold">6. Hak Kekayaan Intelektual</h5>
        <p>
          Semua konten yang ditampilkan pada situs ini, termasuk logo, teks, dan desain, dilindungi oleh hak cipta. Dilarang menyalin atau menggunakan konten tanpa izin tertulis dari pemilik situs.
        </p>
      </div>
    </div>
  </div>
</div>




<?php require '../lib/footer.php'; ?>